import type { Order } from "@/http/apis/order"
import { ElMessage } from "element-plus"
import { defineStore } from "pinia"
import { ref } from "vue"
import {
  createOrderApi,
  deleteOrderApi,
  getOrderListApi,

  updateOrderApi
} from "@/http/apis/order"

export const useOrderStore = defineStore(
  "order",
  () => {
    const list = ref<Order[]>([])
    const loading = ref(false)

    async function fetchList() {
      loading.value = true
      try {
        const response = await getOrderListApi()
        list.value = response.data
        return response.data
      } catch (error) {
        ElMessage.error("获取订单列表失败")
        throw error
      } finally {
        loading.value = false
      }
    }

    async function create(data: Omit<Order, "id" | "createTime">) {
      loading.value = true
      try {
        const response = await createOrderApi(data)
        list.value.push(response.data)
        ElMessage.success("创建成功")
        return response.data
      } catch (error) {
        ElMessage.error("创建失败")
        throw error
      } finally {
        loading.value = false
      }
    }

    async function update(id: number, data: Partial<Order>) {
      loading.value = true
      try {
        const response = await updateOrderApi(id, data)
        const index = list.value.findIndex(o => o.id === id)
        if (index !== -1) {
          list.value[index] = response.data
        }
        ElMessage.success("更新成功")
        return response.data
      } catch (error) {
        ElMessage.error("更新失败")
        throw error
      } finally {
        loading.value = false
      }
    }

    async function deleteOrder(id: number) {
      loading.value = true
      try {
        await deleteOrderApi(id)
        const index = list.value.findIndex(o => o.id === id)
        if (index !== -1) {
          list.value.splice(index, 1)
        }
        ElMessage.success("删除成功")
      } catch (error) {
        ElMessage.error("删除失败")
        throw error
      } finally {
        loading.value = false
      }
    }

    return { list, loading, fetchList, create, update, deleteOrder }
  },
  {
    persist: false
  }
)
